using System;
using System.Windows.Forms;

namespace DiabetesAIMLWinForms
{
    // Lightweight wrapper to reuse SahsiTestDialog and keep existing usage.
    public class SahsiTestForm : Form
    {
        private SahsiTestDialog _dialog;
        public int ResultPercent { get; private set; }

        public SahsiTestForm()
        {
            _dialog = new SahsiTestDialog();
        }

        public new DialogResult ShowDialog(IWin32Window owner)
        {
            var dr = _dialog.ShowDialog(owner);
            if (dr == DialogResult.OK)
            {
                this.ResultPercent = _dialog.ResultPercent;
            }
            return dr;
        }

        public new DialogResult ShowDialog()
        {
            var dr = _dialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                this.ResultPercent = _dialog.ResultPercent;
            }
            return dr;
        }
    }
}
