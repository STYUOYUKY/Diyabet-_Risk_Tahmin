using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace DiabetesAIMLWinForms
{
    public class AnalysisForm : Form
    {
        private Dictionary<string, double> _scores;
        private string _bestModel;
        private double _ensemble;

        public AnalysisForm(Dictionary<string, double> scores, string bestModel, double ensemble)
        {
            _scores = scores ?? new Dictionary<string, double>();
            _bestModel = bestModel;
            _ensemble = ensemble;

            InitializeUI();
        }

        private void InitializeUI()
        {
            this.Text = "Analiz ve Oneriler";
            this.ClientSize = new Size(820, 420);
            this.StartPosition = FormStartPosition.CenterParent;
            this.Font = new Font("Segoe UI", 9F);
            this.BackColor = Color.FromArgb(246, 247, 249);

            var layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 2;
            layout.RowCount = 1;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));
            layout.Padding = new Padding(12);
            layout.BackColor = Color.Transparent;

            var pb = new PictureBox();
            pb.Dock = DockStyle.Fill;
            pb.BackColor = Color.White;
            pb.Margin = new Padding(6);
            pb.Paint += Pb_Paint;

            var card = new Panel();
            card.Dock = DockStyle.Fill;
            card.Margin = new Padding(6);
            card.Padding = new Padding(14);
            card.BackColor = Color.White;
            card.BorderStyle = BorderStyle.FixedSingle;

            var title = new Label();
            title.Text = "Analiz ve Oneriler";
            title.Font = new Font(this.Font.FontFamily, 14F, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(34, 34, 34);
            title.AutoSize = true;

            var spacer = new Label();
            spacer.Height = 8;

            var bestLbl = new Label();
            bestLbl.Font = new Font(this.Font.FontFamily, 11F, FontStyle.Bold);
            bestLbl.ForeColor = Color.FromArgb(45, 45, 48);
            bestLbl.AutoSize = false;
            bestLbl.Height = 30;
            bestLbl.Dock = DockStyle.Top;
            if (!string.IsNullOrEmpty(_bestModel) && _scores.ContainsKey(_bestModel))
                bestLbl.Text = $"En iyi model: {_bestModel} ({_scores[_bestModel]:P0})";
            else
                bestLbl.Text = "En iyi model: N/A";

            var ensembleLbl = new Label();
            ensembleLbl.Font = new Font(this.Font.FontFamily, 11F, FontStyle.Bold);
            ensembleLbl.ForeColor = Color.FromArgb(34, 120, 200);
            ensembleLbl.AutoSize = false;
            ensembleLbl.Height = 30;
            ensembleLbl.Dock = DockStyle.Top;
            ensembleLbl.Text = $"Ensemble (ortalama): {_ensemble:P0}";

            var sep = new Label();
            sep.Height = 8;

            var summary = new Label();
            summary.Dock = DockStyle.Fill;
            summary.Font = new Font(this.Font.FontFamily, 10F);
            summary.ForeColor = Color.FromArgb(80, 80, 80);
            summary.AutoSize = false;

            var sb = new System.Text.StringBuilder();
            if (_ensemble >= 0.80)
                sb.AppendLine("Analiz: Model performansi yuksek - modeller guvenilir gorunuyor.");
            else if (_ensemble >= 0.70)
                sb.AppendLine("Analiz: Model performansi makul - daha fazla veri ile gelistirilebilir.");
            else
                sb.AppendLine("Analiz: Model performansi dusuk - daha fazla veri veya on isleme gerekebilir.");

            sb.AppendLine();
            sb.AppendLine("Oneriler:");
            sb.AppendLine("� M�mk�nse daha fazla egitim verisi toplayin.");
            sb.AppendLine("� Ek on isleme ve ozellik muhendisligi uygulayin.");
            sb.AppendLine("� Modelleri ayri bir hold-out veri ile dogrulayin ve cross-validation kullanin.");

            summary.Text = sb.ToString();

            // Add controls to card (stack)
            card.Controls.Add(summary);
            card.Controls.Add(sep);
            card.Controls.Add(ensembleLbl);
            card.Controls.Add(bestLbl);
            card.Controls.Add(spacer);
            card.Controls.Add(title);

            layout.Controls.Add(pb, 0, 0);
            layout.Controls.Add(card, 1, 0);

            this.Controls.Add(layout);
        }

        private void Pb_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.White);

            if (_scores == null || _scores.Count == 0)
            {
                using (var f = new Font(this.Font.FontFamily, 12, FontStyle.Bold))
                using (var brush = new SolidBrush(Color.Gray))
                {
                    g.DrawString("No scores to display", f, brush, 10, 10);
                }
                return;
            }

            var pb = (PictureBox)sender;
            int w = pb.ClientSize.Width;
            int h = pb.ClientSize.Height;

            // margins for axes
            int leftMargin = 60;
            int rightMargin = 20;
            int topMargin = 20;
            int bottomMargin = 60;

            Rectangle plotArea = new Rectangle(leftMargin, topMargin, w - leftMargin - rightMargin, h - topMargin - bottomMargin);

            // background rect with rounded corners
            using (var bgBrush = new SolidBrush(Color.FromArgb(250, 250, 250)))
            using (var pen = new Pen(Color.FromArgb(230, 230, 230)))
            {
                var r = new Rectangle(plotArea.Left - 8, plotArea.Top - 8, plotArea.Width + 16, plotArea.Height + 16);
                using (var path = CreateRoundRectPath(r, 8))
                {
                    g.FillPath(bgBrush, path);
                    g.DrawPath(pen, path);
                }
            }

            // draw grid lines
            using (var gridPen = new Pen(Color.FromArgb(230, 230, 230)))
            {
                int yLines = 5;
                for (int i = 0; i <= yLines; i++)
                {
                    int yy = plotArea.Top + i * plotArea.Height / yLines;
                    g.DrawLine(gridPen, plotArea.Left, yy, plotArea.Right, yy);
                }

                int xCount = _scores.Count - 1;
                for (int i = 0; i <= xCount; i++)
                {
                    int xx = plotArea.Left + i * (plotArea.Width) / Math.Max(1, xCount);
                    g.DrawLine(gridPen, xx, plotArea.Top, xx, plotArea.Bottom);
                }
            }

            // axes
            using (var axisPen = new Pen(Color.FromArgb(140, 140, 140), 1.5f))
            {
                g.DrawLine(axisPen, plotArea.Left, plotArea.Top, plotArea.Left, plotArea.Bottom);
                g.DrawLine(axisPen, plotArea.Left, plotArea.Bottom, plotArea.Right, plotArea.Bottom);
            }

            // Y ticks and labels
            using (var font = new Font(this.Font.FontFamily, 9))
            using (var brush = new SolidBrush(Color.FromArgb(90, 90, 90)))
            {
                for (int i = 0; i <= 5; i++)
                {
                    double val = 1.0 - i * 0.2;
                    int yy = plotArea.Top + (int)((1.0 - val) * plotArea.Height);
                    string label = string.Format("{0:P0}", val);
                    var size = g.MeasureString(label, font);
                    g.DrawString(label, font, brush, plotArea.Left - size.Width - 8, yy - size.Height / 2);
                }

                int idx = 0;
                int count = _scores.Count;
                foreach (var kv in _scores)
                {
                    int xx = plotArea.Left + (int)((double)idx / Math.Max(1, count - 1) * plotArea.Width);
                    var label = kv.Key;
                    var labelRect = new RectangleF(xx - 60, plotArea.Bottom + 6, 120, 36);
                    var sf = new StringFormat();
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Near;
                    g.DrawString(label, font, brush, labelRect, sf);
                    idx++;
                }
            }

            // compute points
            var points = new List<PointF>();
            int pos = 0; int total = _scores.Count;
            foreach (var kv in _scores)
            {
                double value = Math.Max(0.0, Math.Min(1.0, kv.Value));
                float x = plotArea.Left + (float)pos / Math.Max(1, total - 1) * plotArea.Width;
                float y = plotArea.Top + (1f - (float)value) * plotArea.Height;
                points.Add(new PointF(x, y));
                pos++;
            }

            // draw smooth curve using Bezier
            if (points.Count >= 2)
            {
                using (var path = new GraphicsPath())
                {
                    path.AddLines(points.ToArray());
                    using (var pen = new Pen(Color.FromArgb(45, 120, 220), 3))
                    {
                        pen.LineJoin = LineJoin.Round;
                        g.DrawPath(pen, path);
                    }
                }
            }

            // points with halo and label
            int iPoint = 0;
            var colors = new[] { Color.FromArgb(33,150,243), Color.FromArgb(76,175,80), Color.FromArgb(255,152,0), Color.FromArgb(156,39,176) };
            int markerRadius = 6;
            foreach (var p in points)
            {
                // halo
                using (var haloBrush = new SolidBrush(Color.FromArgb(30, colors[iPoint % colors.Length])))
                {
                    g.FillEllipse(haloBrush, p.X - markerRadius - 6, p.Y - markerRadius - 6, (markerRadius + 6) * 2, (markerRadius + 6) * 2);
                }

                // main marker
                using (var markerBrush = new SolidBrush(colors[iPoint % colors.Length]))
                using (var pen = new Pen(ControlPaint.Dark(colors[iPoint % colors.Length]), 2))
                {
                    g.FillEllipse(markerBrush, p.X - markerRadius, p.Y - markerRadius, markerRadius * 2, markerRadius * 2);
                    g.DrawEllipse(pen, p.X - markerRadius, p.Y - markerRadius, markerRadius * 2, markerRadius * 2);
                }

                // value label
                using (var font = new Font(this.Font.FontFamily, 9, FontStyle.Bold))
                using (var brush = new SolidBrush(Color.FromArgb(50, 50, 50)))
                {
                    string valText = string.Format("{0:P0}", _scores.ElementAt(iPoint).Value);
                    var sz = g.MeasureString(valText, font);
                    g.DrawString(valText, font, brush, p.X - sz.Width / 2, p.Y - markerRadius - sz.Height - 6);
                }

                iPoint++;
            }

            // ensemble dotted line
            double ensemble = Math.Max(0.0, Math.Min(1.0, _ensemble));
            int lineY = plotArea.Top + (int)((1.0 - ensemble) * plotArea.Height);
            using (var pen = new Pen(Color.FromArgb(200, 220, 20, 60), 2))
            {
                pen.DashStyle = DashStyle.DashDot;
                g.DrawLine(pen, plotArea.Left, lineY, plotArea.Right, lineY);
            }

            using (var font = new Font(this.Font.FontFamily, 9, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.FromArgb(180, 220, 20, 60)))
            {
                g.DrawString($"Ensemble: {ensemble:P0}", font, brush, plotArea.Right - 120, lineY - 18);
            }
        }

        private GraphicsPath CreateRoundRectPath(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int diameter = radius * 2;
            Rectangle arc = new Rectangle(r.Location, new Size(diameter, diameter));

            // top-left
            arc.Location = new Point(r.Left, r.Top);
            path.AddArc(arc, 180, 90);

            // top-right
            arc.X = r.Right - diameter;
            path.AddArc(arc, 270, 90);

            // bottom-right
            arc.Y = r.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            // bottom-left
            arc.X = r.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }
}
