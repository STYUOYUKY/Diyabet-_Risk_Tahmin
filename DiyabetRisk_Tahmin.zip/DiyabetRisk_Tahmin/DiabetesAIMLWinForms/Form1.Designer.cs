﻿namespace DiabetesAIMLWinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblTahmin = new System.Windows.Forms.Label();
            this.lblVeriBilgi = new System.Windows.Forms.Label();
            this.btnVeriYukle = new System.Windows.Forms.Button();
            this.btnOnIslemeUygula = new System.Windows.Forms.Button();
            this.btnModelEgit = new System.Windows.Forms.Button();
            this.btnTahmin = new System.Windows.Forms.Button();
            this.btnSahsiTest = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(560, 350);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(45, 45, 48);
            this.dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(250, 250, 250);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 368);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(560, 23);
            this.progressBar1.TabIndex = 1;
            // 
            // lblTahmin
            // 
            this.lblTahmin.AutoSize = true;
            this.lblTahmin.Location = new System.Drawing.Point(590, 12);
            this.lblTahmin.Name = "lblTahmin";
            this.lblTahmin.Size = new System.Drawing.Size(46, 17);
            this.lblTahmin.TabIndex = 2;
            this.lblTahmin.Text = "Tahmin";
            this.lblTahmin.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            // 
            // lblVeriBilgi
            // 
            this.lblVeriBilgi.AutoSize = true;
            this.lblVeriBilgi.Location = new System.Drawing.Point(590, 50);
            this.lblVeriBilgi.Name = "lblVeriBilgi";
            this.lblVeriBilgi.Size = new System.Drawing.Size(46, 17);
            this.lblVeriBilgi.TabIndex = 3;
            this.lblVeriBilgi.Text = "Veri yok";
            this.lblVeriBilgi.Font = new System.Drawing.Font("Segoe UI", 9F);
            // 
            // btnVeriYukle
            // 
            this.btnVeriYukle.Location = new System.Drawing.Point(593, 90);
            this.btnVeriYukle.Name = "btnVeriYukle";
            this.btnVeriYukle.Size = new System.Drawing.Size(180, 30);
            this.btnVeriYukle.TabIndex = 4;
            this.btnVeriYukle.Text = "Veri Yukle";
            this.btnVeriYukle.UseVisualStyleBackColor = true;
            this.btnVeriYukle.Click += new System.EventHandler(this.btnVeriYukle_Click);
            this.btnVeriYukle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVeriYukle.FlatAppearance.BorderSize = 0;
            this.btnVeriYukle.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnVeriYukle.ForeColor = System.Drawing.Color.White;
            this.btnVeriYukle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.btnVeriYukle.Cursor = System.Windows.Forms.Cursors.Hand;
            // 
            // btnOnIslemeUygula
            // 
            this.btnOnIslemeUygula.Location = new System.Drawing.Point(593, 136);
            this.btnOnIslemeUygula.Name = "btnOnIslemeUygula";
            this.btnOnIslemeUygula.Size = new System.Drawing.Size(180, 30);
            this.btnOnIslemeUygula.TabIndex = 5;
            this.btnOnIslemeUygula.Text = "On Isleme Uygula";
            this.btnOnIslemeUygula.UseVisualStyleBackColor = true;
            this.btnOnIslemeUygula.Click += new System.EventHandler(this.btnOnIslemeUygula_Click);
            this.btnOnIslemeUygula.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOnIslemeUygula.FlatAppearance.BorderSize = 0;
            this.btnOnIslemeUygula.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnOnIslemeUygula.ForeColor = System.Drawing.Color.White;
            this.btnOnIslemeUygula.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnOnIslemeUygula.Cursor = System.Windows.Forms.Cursors.Hand;
            // 
            // btnModelEgit
            // 
            this.btnModelEgit.Location = new System.Drawing.Point(593, 182);
            this.btnModelEgit.Name = "btnModelEgit";
            this.btnModelEgit.Size = new System.Drawing.Size(180, 30);
            this.btnModelEgit.TabIndex = 6;
            this.btnModelEgit.Text = "Model Egit";
            this.btnModelEgit.UseVisualStyleBackColor = true;
            this.btnModelEgit.Click += new System.EventHandler(this.btnModelEgit_Click);
            this.btnModelEgit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModelEgit.FlatAppearance.BorderSize = 0;
            this.btnModelEgit.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnModelEgit.ForeColor = System.Drawing.Color.White;
            this.btnModelEgit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnModelEgit.Cursor = System.Windows.Forms.Cursors.Hand;
            // 
            // btnTahmin
            // 
            this.btnTahmin.Location = new System.Drawing.Point(593, 228);
            this.btnTahmin.Name = "btnTahmin";
            this.btnTahmin.Size = new System.Drawing.Size(180, 30);
            this.btnTahmin.TabIndex = 7;
            this.btnTahmin.Text = "Tahmin";
            this.btnTahmin.UseVisualStyleBackColor = true;
            this.btnTahmin.Click += new System.EventHandler(this.btnTahmin_Click);
            this.btnTahmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTahmin.FlatAppearance.BorderSize = 0;
            this.btnTahmin.BackColor = System.Drawing.Color.FromArgb(76, 175, 80);
            this.btnTahmin.ForeColor = System.Drawing.Color.White;
            this.btnTahmin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTahmin.Cursor = System.Windows.Forms.Cursors.Hand;
            // 
            // btnSahsiTest
            // 
            this.btnSahsiTest.Location = new System.Drawing.Point(593, 274);
            this.btnSahsiTest.Name = "btnSahsiTest";
            this.btnSahsiTest.Size = new System.Drawing.Size(180, 30);
            this.btnSahsiTest.TabIndex = 8;
            this.btnSahsiTest.Text = "Sahsi Test";
            this.btnSahsiTest.UseVisualStyleBackColor = true;
            this.btnSahsiTest.Click += new System.EventHandler(this.btnSahsiTest_Click);
            this.btnSahsiTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSahsiTest.FlatAppearance.BorderSize = 0;
            this.btnSahsiTest.BackColor = System.Drawing.Color.FromArgb(255, 152, 0);
            this.btnSahsiTest.ForeColor = System.Drawing.Color.White;
            this.btnSahsiTest.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSahsiTest.Cursor = System.Windows.Forms.Cursors.Hand;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSahsiTest);
            this.Controls.Add(this.btnTahmin);
            this.Controls.Add(this.btnModelEgit);
            this.Controls.Add(this.btnOnIslemeUygula);
            this.Controls.Add(this.btnVeriYukle);
            this.Controls.Add(this.lblVeriBilgi);
            this.Controls.Add(this.lblTahmin);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Diyabet AIML";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BackColor = System.Drawing.Color.White;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lblTahmin;
        private System.Windows.Forms.Label lblVeriBilgi;
        private System.Windows.Forms.Button btnVeriYukle;
        private System.Windows.Forms.Button btnOnIslemeUygula;
        private System.Windows.Forms.Button btnModelEgit;
        private System.Windows.Forms.Button btnTahmin;
        private System.Windows.Forms.Button btnSahsiTest;
    }
}

