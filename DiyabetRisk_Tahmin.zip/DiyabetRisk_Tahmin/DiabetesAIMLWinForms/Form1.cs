﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DiabetesAIMLWinForms.Services;

namespace DiabetesAIMLWinForms
{
    public partial class Form1 : Form
    {
        DataTable veriTablosu;

        public Form1()
        {
            InitializeComponent();
            lblTahmin.Text = string.Empty;
            lblVeriBilgi.Text = "Veri yok";
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Value = 0;

            // Ensure DataGridView selection settings
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }

        private void btnVeriYukle_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "CSV dosyalari (*.csv)|*.csv|Tum dosyalar (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    veriTablosu = CsvService.CsvOku(ofd.FileName);
                    dataGridView1.DataSource = veriTablosu;
                    lblVeriBilgi.Text = veriTablosu != null ? $"Satir sayisi: {veriTablosu.Rows.Count}" : "Veri yok";
                }
            }
        }

        private void btnOnIslemeUygula_Click(object sender, EventArgs e)
        {
            if (veriTablosu == null)
            {
                MessageBox.Show("Once veri yukleyin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            PreprocessService.SifirlariDoldur(veriTablosu, "Glucose");
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = veriTablosu;
            MessageBox.Show("On isleme tamamlandi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnModelEgit_Click(object sender, EventArgs e)
        {
            if (veriTablosu != null)
            {
                ModelService.Train(veriTablosu);
            }

            var lr = ModelService.LogisticRegression();
            var rf = ModelService.RandomForest();
            var svm = ModelService.SVM();
            var knn = ModelService.KNN();

            // Analysis
            var scores = new System.Collections.Generic.Dictionary<string, double>
            {
                { "LogisticRegression", lr },
                { "RandomForest", rf },
                { "SVM", svm },
                { "KNN", knn }
            };

            double sum = 0.0;
            string bestModel = null;
            double bestScore = double.MinValue;
            foreach (var kv in scores)
            {
                sum += kv.Value;
                if (kv.Value > bestScore)
                {
                    bestScore = kv.Value;
                    bestModel = kv.Key;
                }
            }

            double ensemble = scores.Count > 0 ? sum / scores.Count : 0.0;

            // show analysis form with chart
            var analysisForm = new AnalysisForm(scores, bestModel, ensemble);
            analysisForm.ShowDialog(this);

            // Update summary label
            lblVeriBilgi.Text = $"Best: {bestModel} {bestScore:P0}, Ensemble: {ensemble:P0}";
        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            // require a selected row
            if (dataGridView1.SelectedRows == null || dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Tahmin yapmak icin bir satir secin.", "Uyari", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var sel = dataGridView1.SelectedRows[0];
            if (sel == null || sel.DataBoundItem == null)
            {
                MessageBox.Show("Gecerli bir satir secin.", "Uyari", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRowView drv = sel.DataBoundItem as DataRowView;
            if (drv == null)
            {
                MessageBox.Show("Secilen veri islenemedi.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var row = drv.Row;

            double risk = ModelService.Predict(row);
            int percent = (int)Math.Round(risk * 100.0);

            // clamp and set progress
            if (percent < progressBar1.Minimum) percent = progressBar1.Minimum;
            if (percent > progressBar1.Maximum) percent = progressBar1.Maximum;
            progressBar1.Value = percent;

            lblTahmin.Text = $"Diyabet Riski: %{percent}\nYorum: {(percent >= 50 ? "Yuksek risk; takip onerilir" : "Dusuk risk")}";
        }

        private void btnSahsiTest_Click(object sender, EventArgs e)
        {
            using (var form = new SahsiTestDialog())
            {
                form.StartPosition = FormStartPosition.CenterParent;
                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    int percent = form.ResultPercent;
                    if (percent < progressBar1.Minimum) percent = progressBar1.Minimum;
                    if (percent > progressBar1.Maximum) percent = progressBar1.Maximum;
                    progressBar1.Value = percent;
                    lblTahmin.Text = $"Diyabet Riski: %{percent}\nYorum: {(percent >= 50 ? "Yuksek risk; doktorunuza danisin" : (percent >= 20 ? "Orta risk; yasam tarzi onlemleri" : "Dusuk risk"))}";
                }
            }
        }
    }
}
