namespace DiabetesAIMLWinForms.Services
{
    using System;
    using System.Data;
    using System.IO;

    public static class CsvService
    {
        // Reads a CSV file where first line is header and separator is comma
        public static DataTable CsvOku(string path)
        {
            var dt = new DataTable();
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
                return dt;

            var lines = File.ReadAllLines(path);
            if (lines.Length == 0)
                return dt;

            var headers = lines[0].Split(',');
            foreach (var h in headers)
            {
                var colName = string.IsNullOrWhiteSpace(h) ? "Column" + dt.Columns.Count : h.Trim();
                dt.Columns.Add(colName);
            }

            for (int i = 1; i < lines.Length; i++)
            {
                var parts = lines[i].Split(',');
                var row = dt.NewRow();
                for (int c = 0; c < dt.Columns.Count; c++)
                {
                    if (c < parts.Length)
                        row[c] = string.IsNullOrEmpty(parts[c]) ? string.Empty : parts[c].Trim();
                    else
                        row[c] = string.Empty;
                }
                dt.Rows.Add(row);
            }

            return dt;
        }
    }
}
