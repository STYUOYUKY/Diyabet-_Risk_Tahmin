namespace DiabetesAIMLWinForms.Services
{
    using System;
    using System.Data;
    using System.Globalization;

    public static class PreprocessService
    {
        // Fills zeros or empty values in the specified column with the column mean
        public static void SifirlariDoldur(DataTable dt, string kolonAdi)
        {
            if (dt == null || string.IsNullOrWhiteSpace(kolonAdi) || !dt.Columns.Contains(kolonAdi))
                return;

            double sum = 0;
            int count = 0;

            foreach (DataRow row in dt.Rows)
            {
                var valObj = row[kolonAdi];
                if (valObj == null)
                    continue;

                var s = Convert.ToString(valObj);
                if (string.IsNullOrWhiteSpace(s) || s == "0" )
                    continue; // will treat as missing for mean calculation

                if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out double v))
                {
                    sum += v;
                    count++;
                }
            }

            double mean = count > 0 ? sum / count : 0.0;

            foreach (DataRow row in dt.Rows)
            {
                var s = Convert.ToString(row[kolonAdi]);
                if (string.IsNullOrWhiteSpace(s) || s == "0")
                {
                    row[kolonAdi] = mean.ToString(CultureInfo.InvariantCulture);
                }
            }
        }
    }
}
