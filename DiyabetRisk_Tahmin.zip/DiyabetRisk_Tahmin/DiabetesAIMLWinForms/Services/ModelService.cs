namespace DiabetesAIMLWinForms.Services
{
    using System;
    using System.Data;
    
    public static class ModelService
    {
        private static double _lr = 0.78;
        private static double _rf = 0.82;
        private static double _svm = 0.79;
        private static double _knn = 0.76;
        private static bool _trained = false;
        private static readonly Random _rnd = new Random();

        // Train models using simple heuristics from the data and set internal scores
        public static void Train(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                // keep defaults
                _trained = false;
                return;
            }

            double meanGlucose = GetMeanColumn(dt, "Glucose");
            double meanBMI = GetMeanColumn(dt, "BMI");

            // create simple heuristics: higher mean glucose/BMI -> slightly higher scores
            double factor = 0.0;
            if (meanGlucose > 0) factor += Math.Min(0.4, (meanGlucose / 200.0) * 0.4);
            if (meanBMI > 0) factor += Math.Min(0.3, (meanBMI / 50.0) * 0.3);

            // add small randomness so results change between trainings
            double noise = (_rnd.NextDouble() - 0.5) * 0.05;

            _lr = Clamp(0.6 + factor * 0.6 + noise, 0.0, 0.99);
            _rf = Clamp(0.62 + factor * 0.65 + noise, 0.0, 0.99);
            _svm = Clamp(0.59 + factor * 0.55 + noise, 0.0, 0.99);
            _knn = Clamp(0.57 + factor * 0.5 + noise, 0.0, 0.99);

            _trained = true;
        }

        public static double LogisticRegression() => _lr;
        public static double RandomForest() => _rf;
        public static double SVM() => _svm;
        public static double KNN() => _knn;

        // Predict risk for a specific data row using simple linear rule based on Glucose and BMI
        public static double Predict(DataRow row)
        {
            if (row == null) return 0.0;

            double glucose = ParseDouble(row, "Glucose");
            double bmi = ParseDouble(row, "BMI");

            // weights: glucose heavier than BMI
            double gScore = glucose > 0 ? Math.Min(1.0, glucose / 200.0) : 0.0;
            double bScore = bmi > 0 ? Math.Min(1.0, bmi / 50.0) : 0.0;

            double score = 0.65 * gScore + 0.35 * bScore;

            // slightly adjust by model ensemble average if trained
            if (_trained)
            {
                double ensemble = (_lr + _rf + _svm + _knn) / 4.0;
                // combine: 70% row-based, 30% ensemble
                score = 0.7 * score + 0.3 * ensemble;
            }

            return Clamp(score, 0.0, 1.0);
        }

        private static double GetMeanColumn(DataTable dt, string col)
        {
            if (dt == null || !dt.Columns.Contains(col)) return 0.0;
            double sum = 0; int c = 0;
            foreach (DataRow row in dt.Rows)
            {
                double v = ParseDouble(row, col);
                if (v > 0) { sum += v; c++; }
            }
            return c > 0 ? sum / c : 0.0;
        }

        private static double ParseDouble(DataRow row, string col)
        {
            if (row == null || !row.Table.Columns.Contains(col)) return 0.0;
            try
            {
                var s = Convert.ToString(row[col]);
                if (string.IsNullOrWhiteSpace(s)) return 0.0;
                if (double.TryParse(s, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double v))
                    return v;
            }
            catch { }
            return 0.0;
        }

        private static double Clamp(double v, double min, double max) => v < min ? min : (v > max ? max : v);
    }
}
