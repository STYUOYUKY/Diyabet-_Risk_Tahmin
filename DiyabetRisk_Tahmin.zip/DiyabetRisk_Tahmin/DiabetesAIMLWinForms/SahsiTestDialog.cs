using System;
using System.Drawing;
using System.Windows.Forms;

namespace DiabetesAIMLWinForms
{
    public class SahsiTestDialog : Form
    {
        private NumericUpDown nudAge;
        private ComboBox cbGender;
        private NumericUpDown nudGlucose;
        private NumericUpDown nudBMI;
        private Button btnOk;
        private Button btnCancel;
        private Label lblResult;

        public int ResultPercent { get; private set; }

        public SahsiTestDialog()
        {
            Init();
        }

        private void Init()
        {
            this.Text = "Sahsi Test";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.ClientSize = new Size(380, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.Font = new Font("Segoe UI", 9F);

            var lblAge = new Label();
            lblAge.Text = "Yas:";
            lblAge.Location = new Point(12, 12);
            lblAge.AutoSize = true;
            this.Controls.Add(lblAge);

            nudAge = new NumericUpDown();
            nudAge.Location = new Point(160, 10);
            nudAge.Size = new Size(200, 22);
            nudAge.Minimum = 0;
            nudAge.Maximum = 120;
            nudAge.Value = 30;
            this.Controls.Add(nudAge);

            var lblGender = new Label();
            lblGender.Text = "Cinsiyet:";
            lblGender.Location = new Point(12, 48);
            lblGender.AutoSize = true;
            this.Controls.Add(lblGender);

            cbGender = new ComboBox();
            cbGender.Location = new Point(160, 46);
            cbGender.Size = new Size(200, 22);
            cbGender.DropDownStyle = ComboBoxStyle.DropDownList;
            cbGender.Items.Add("Kadin");
            cbGender.Items.Add("Erkek");
            cbGender.SelectedIndex = 0;
            this.Controls.Add(cbGender);

            var lblGl = new Label();
            lblGl.Text = "Aclik Kan Sekeri (mg/dL):";
            lblGl.Location = new Point(12, 84);
            lblGl.AutoSize = true;
            this.Controls.Add(lblGl);

            nudGlucose = new NumericUpDown();
            nudGlucose.Location = new Point(160, 82);
            nudGlucose.Size = new Size(200, 22);
            nudGlucose.Minimum = 0;
            nudGlucose.Maximum = 1000;
            nudGlucose.Value = 90;
            this.Controls.Add(nudGlucose);

            var lblBmi = new Label();
            lblBmi.Text = "BMI:";
            lblBmi.Location = new Point(12, 120);
            lblBmi.AutoSize = true;
            this.Controls.Add(lblBmi);

            nudBMI = new NumericUpDown();
            nudBMI.Location = new Point(160, 118);
            nudBMI.Size = new Size(200, 22);
            nudBMI.Minimum = 0;
            nudBMI.Maximum = 100;
            nudBMI.DecimalPlaces = 1;
            nudBMI.Increment = 0.1M;
            nudBMI.Value = 24;
            this.Controls.Add(nudBMI);

            btnOk = new Button();
            btnOk.Text = "Hesapla";
            btnOk.Location = new Point(160, 160);
            btnOk.Size = new Size(90, 34);
            btnOk.BackColor = Color.FromArgb(33, 150, 243);
            btnOk.ForeColor = Color.White;
            btnOk.FlatStyle = FlatStyle.Flat;
            btnOk.Click += BtnOk_Click;
            this.Controls.Add(btnOk);

            btnCancel = new Button();
            btnCancel.Text = "Iptal";
            btnCancel.Location = new Point(270, 160);
            btnCancel.Size = new Size(90, 34);
            btnCancel.BackColor = Color.Gray;
            btnCancel.ForeColor = Color.White;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };
            this.Controls.Add(btnCancel);

            lblResult = new Label();
            lblResult.Location = new Point(12, 210);
            lblResult.Size = new Size(348, 64);
            lblResult.Font = new Font(this.Font.FontFamily, 10F, FontStyle.Bold);
            this.Controls.Add(lblResult);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            int age = (int)nudAge.Value;
            int glucose = (int)nudGlucose.Value;
            double bmi = (double)nudBMI.Value;
            string gender = cbGender.SelectedItem != null ? cbGender.SelectedItem.ToString() : "Kadin";

            if (glucose >= 126)
            {
                ResultPercent = 95;
                lblResult.Text = "Sonuc: Diyabet olasi (yuksek). Doktora basvurun.";
                this.DialogResult = DialogResult.OK;
                this.Close();
                return;
            }

            double gScore = glucose > 0 ? Math.Min(1.0, glucose / 200.0) : 0.0;
            double bScore = bmi > 0 ? Math.Min(1.0, bmi / 50.0) : 0.0;
            double aScore = age > 30 ? Math.Min(1.0, (age - 30) / 70.0) : 0.0;

            double score = 0.6 * gScore + 0.3 * bScore + 0.1 * aScore;
            if (gender == "Erkek") score += 0.02;

            int percent = (int)Math.Round(Math.Max(0.0, Math.Min(1.0, score)) * 100.0);
            ResultPercent = percent;

            string yorum = percent >= 50 ? "Yuksek risk; doktorunuza danisin." : (percent >= 20 ? "Orta risk; yasam tarzi degisiklikleri dusunulebilir." : "Dusuk risk.");

            lblResult.Text = "Diyabet riski: %" + percent.ToString() + " - " + yorum;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
